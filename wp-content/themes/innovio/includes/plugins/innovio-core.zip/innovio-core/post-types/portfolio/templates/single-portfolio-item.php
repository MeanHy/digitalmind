<?php

get_header();

innovio_mikado_get_title();

do_action('innovio_mikado_action_before_main_content');

innovio_core_get_single_portfolio();

get_footer();