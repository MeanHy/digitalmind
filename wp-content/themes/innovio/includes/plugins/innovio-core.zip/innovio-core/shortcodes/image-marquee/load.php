<?php

include_once INNOVIO_CORE_SHORTCODES_PATH . '/image-marquee/functions.php';
include_once INNOVIO_CORE_SHORTCODES_PATH . '/image-marquee/image-marquee.php';