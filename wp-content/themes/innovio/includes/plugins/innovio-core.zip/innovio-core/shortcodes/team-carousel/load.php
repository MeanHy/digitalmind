<?php

include_once INNOVIO_CORE_SHORTCODES_PATH . '/team-carousel/functions.php';
include_once INNOVIO_CORE_SHORTCODES_PATH . '/team-carousel/team-carousel.php';