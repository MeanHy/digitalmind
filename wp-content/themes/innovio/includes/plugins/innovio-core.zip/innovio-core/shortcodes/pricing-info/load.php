<?php

include_once INNOVIO_CORE_SHORTCODES_PATH . '/pricing-info/functions.php';
include_once INNOVIO_CORE_SHORTCODES_PATH . '/pricing-info/pricing-info.php';