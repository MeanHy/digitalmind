<div class="mkdf-full-screen-image-slider <?php echo esc_attr($holder_classes); ?>">
	<div class="mkdf-fsis-slider mkdf-owl-slider" <?php echo innovio_mikado_get_inline_attrs($slider_data); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
	<div class="mkdf-fsis-thumb-nav mkdf-fsis-prev-nav"></div>
	<div class="mkdf-fsis-thumb-nav mkdf-fsis-next-nav"></div>
	<div class="mkdf-fsis-slider-mask"></div>
</div>