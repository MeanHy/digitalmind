<?php

include_once INNOVIO_CORE_SHORTCODES_PATH . '/text-marquee/functions.php';
include_once INNOVIO_CORE_SHORTCODES_PATH . '/text-marquee/text-marquee.php';