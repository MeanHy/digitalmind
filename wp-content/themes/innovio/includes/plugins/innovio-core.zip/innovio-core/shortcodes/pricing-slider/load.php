<?php

include_once INNOVIO_CORE_SHORTCODES_PATH . '/pricing-slider/functions.php';
include_once INNOVIO_CORE_SHORTCODES_PATH . '/pricing-slider/pricing-slider.php';