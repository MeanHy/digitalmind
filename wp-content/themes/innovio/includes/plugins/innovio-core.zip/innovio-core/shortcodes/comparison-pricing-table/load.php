<?php

include_once INNOVIO_CORE_SHORTCODES_PATH.'/comparison-pricing-table/functions.php';
include_once INNOVIO_CORE_SHORTCODES_PATH.'/comparison-pricing-table/cpt-holder.php';
include_once INNOVIO_CORE_SHORTCODES_PATH.'/comparison-pricing-table/cpt-table.php';