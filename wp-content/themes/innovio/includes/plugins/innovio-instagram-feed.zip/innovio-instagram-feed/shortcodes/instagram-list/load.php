<?php

include_once INNOVIO_INSTAGRAM_SHORTCODES_PATH . '/instagram-list/functions.php';
include_once INNOVIO_INSTAGRAM_SHORTCODES_PATH . '/instagram-list/instagram-list.php';